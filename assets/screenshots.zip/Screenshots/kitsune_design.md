# Kitsune: A Browser for the Owned Web

**Design Document v0.1**  
**December 2025**

*A companion architecture to Akita Protocol*

---

## Premise

The browser won the platform war. It's the one piece of software that runs on every device, that people trust with their most sensitive data, that mediates nearly all digital interaction. And yet browsers remain stuck in 2005—glorified document viewers with bolted-on features, still assuming the web is a collection of pages served by corporations.

Akita Protocol reimagines social infrastructure. Kitsune reimagines the browser to match. Together, they form a complete stack for human-to-human interaction that doesn't route through corporate intermediaries.

Kitsune is a Firefox fork. We inherit Mozilla's rendering engine, their security model, their extension architecture—and then we add three layers that transform what a browser can be:

1. **Sovereign Identity** — Your cryptographic self, native to the browser
2. **The Agent Runtime** — Local AI that acts on your behalf, within boundaries you control  
3. **The Content Mesh** — A web that's addressed by *what*, not *where*

These aren't features. They're foundations.

---

## Part I: Sovereign Identity

### The Problem with Logging In

Every time you "Sign in with Google," you're asking permission from a corporation to prove you're you. They can say no. They can track every site you visit. They can disappear your identity overnight with no recourse.

Passkeys improved the cryptography but not the topology. Your passkey is still anchored to a platform—Apple's keychain, Google's password manager. The intermediary remains.

### Identity at the Browser Layer

Kitsune makes your identity *native*. When you first run the browser, you generate a keypair. This isn't an account you create with a service. It's a cryptographic identity that exists because math says it does.

This identity anchors everything else:

- **Your Akita smart wallet** derives from this root identity
- **Your social graph** is signed by this identity
- **Your reputation and impact score** accrue to this identity
- **Your agent permissions** are granted by this identity

You can back up this identity (encrypted, to places you control). You can migrate it between devices. But no one can take it from you, because no one issued it to you.

### Credentialing Without Identification

Here's where it gets interesting. Akita's composable gate system lets sites check things about you—your impact score, your stake, your DAO memberships, your NFD ownership—without knowing *who* you are.

Kitsune surfaces this at the browser level. When you visit a site that requests credentials:

```
┌─────────────────────────────────────────────────────┐
│  example.com is requesting:                         │
│                                                     │
│  ☑ Proof of Impact Score > 400                     │
│  ☑ Proof of BONES stake > 1000                     │
│  ☐ Your wallet address (optional)                  │
│                                                     │
│  You can prove these without revealing your identity│
│                                                     │
│         [Deny]                    [Prove]           │
└─────────────────────────────────────────────────────┘
```

The browser generates zero-knowledge proofs or signed attestations from your on-chain state. The site gets a yes/no answer to their gate conditions. They never get your address, your name, or any identifier that persists across sites—unless you choose to give it.

This inverts the power relationship. You're not asking sites to let you in. Sites are asking you to prove you qualify.

### Reputation Portability

Your Akita impact score isn't just for Akita. It's a sybil-resistant, hard-to-game measure of your trustworthiness. Kitsune lets you carry this everywhere.

Imagine a comment section that only shows you comments from people with impact scores above a threshold you set. Or a marketplace where you can filter sellers by their social reputation. Or a forum where posting rights require proof of long-term participation somewhere—anywhere—in the ecosystem.

The browser becomes your reputation wallet, and that reputation is currency more valuable than money in many contexts.

---

## Part II: The Agent Runtime

### Why Agents Need a Home

AI agents are coming. They'll manage your calendar, trade on your behalf, respond to messages, execute transactions. The question isn't whether this happens—it's whether it happens in a way that preserves your sovereignty or destroys it.

If agents run on corporate servers, those corporations see everything. If agents require cloud AI, your data flows through someone else's infrastructure. If agents hold keys to your main wallet, a compromised agent means total loss.

Akita's escrow architecture solves the wallet problem—isolated sub-accounts with limited funds and permissions. But an escrow account without an agent is just a savings account. The agent runtime is what brings it to life.

### Local-First AI

Kitsune runs AI models locally. Not as a gimmick, but as a requirement for the architecture to make sense.

Modern quantized models (Llama 3.2 1B/3B, Phi-3.5-mini, Mistral 7B-instruct) run acceptably on consumer hardware. They're not GPT-4, but they don't need to be. Your agent isn't writing novels. It's:

- Parsing your social feed and surfacing what matters
- Flagging content for moderation review
- Executing pre-authorized transactions when conditions are met
- Responding to routine messages with your voice
- Managing your attention across multiple protocols

These tasks need judgment and language understanding. They don't need frontier capabilities.

### The Sandbox Model

Every agent runs in an isolated context:

```
┌─────────────────────────────────────────────────────┐
│                    KITSUNE BROWSER                  │
├─────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │   Agent A   │  │   Agent B   │  │   Agent C   │ │
│  │  ─────────  │  │  ─────────  │  │  ─────────  │ │
│  │  Model: φ-3 │  │  Model: L3  │  │  Model: M7  │ │
│  │  ─────────  │  │  ─────────  │  │  ─────────  │ │
│  │  Escrow:    │  │  Escrow:    │  │  Escrow:    │ │
│  │  100 AKTA   │  │  500 AKTA   │  │  50 AKTA    │ │
│  │  0 ALGO     │  │  10 ALGO    │  │  0 ALGO     │ │
│  │  ─────────  │  │  ─────────  │  │  ─────────  │ │
│  │  Perms:     │  │  Perms:     │  │  Perms:     │ │
│  │  • upvote   │  │  • upvote   │  │  • read     │ │
│  │  • reply    │  │  • post     │  │  • flag     │ │
│  │  • 10/day   │  │  • 50/day   │  │             │ │
│  └─────────────┘  └─────────────┘  └─────────────┘ │
└─────────────────────────────────────────────────────┘
```

Each agent:
- Runs its own model instance (you can choose different models for different tasks)
- Has access to exactly one escrow account
- Has an explicit permission set (what contract methods it can call)
- Has rate limits (maximum actions per time period)
- Has spending limits (maximum value per transaction, per day)
- Cannot access your root identity or main wallet
- Cannot communicate with other agents except through on-chain state

If an agent goes rogue, the damage is bounded. You lose at most the contents of that escrow and the actions within that permission set. Your core identity, your reputation, your main holdings—untouched.

### Agent Discovery and Sharing

Agents are just configurations: a model choice, a system prompt, a permission set, maybe some fine-tuning. Kitsune includes an agent registry where people share what works.

- "Here's my feed curator. It filters for technical content and summarizes threads over 20 posts."
- "Here's my trading agent. It executes limit orders on whitelisted NFT collections when floor drops 20%."
- "Here's my social responder. It thanks people for upvotes and answers basic questions."

You install these like browser extensions. Review the permissions, fund an escrow, let it run. If it's useful, tip the creator. A marketplace of automation emerges.

### The Attention Layer

Perhaps most importantly, agents become *attention management*. The adversarial attention economy has trained us to be constantly, anxiously checking. Agents can absorb that:

- Your feed agent watches everything, surfaces the 5% that matters
- Your message agent handles routine replies, escalates what needs you
- Your market agent watches prices and opportunities, alerts you to action items

You check in once a day. Or once a week. The agent maintains presence while you maintain sanity. This is what "async-first" actually looks like when you have software that can genuinely act on your behalf.

---

## Part III: The Content Mesh

### Location Addressing is a Vulnerability

When you request `https://example.com/page.html`, you're asking a specific server for a specific file. If that server goes down, the content disappears. If that server is pressured by governments or corporations, the content can be censored. If that server decides to change what's at that URL, you get the new version with no record of what was there before.

This made sense in 1991. It doesn't make sense now.

### Content Addressing as Default

Kitsune treats content-addressed protocols as first-class citizens:

- **IPFS** — The browser maintains a local node. When you visit `ipfs://Qm...`, you're fetching content from the nearest peer who has it. When you browse, you're also seeding—the content you consume, you help distribute.

- **Arweave** — For permanent storage. Content paid for once, hosted forever by the network. The browser resolves `ar://...` addresses natively.

- **Hypercore/Hyperdrive** — For mutable content that's still peer-to-peer. Feeds, documents, datasets that update but aren't centrally hosted.

The URL bar accepts all of these. The browser handles resolution transparently. You often won't know or care whether content came from a traditional server or a distributed network—it just loads.

### Your Node, Your Contribution

Running a browser makes you a participant in the network, not just a consumer. Kitsune includes:

- **Configurable storage allocation** — Dedicate 10GB, 100GB, whatever you're willing to contribute
- **Pinning controls** — Permanently store content you care about preserving
- **Bandwidth shaping** — Contribute more when you're on fast connections, less when you're mobile
- **Seeding incentives** — Integration with Filecoin, Arweave, or Akita's own incentive layer for compensated storage

The web becomes an actual network again—a mesh of peers helping each other access information, rather than clients begging servers for permission.

### Akita Content Integration

Akita already stores social content on IPFS with metadata on-chain. Kitsune makes this seamless:

- Social feed content loads from the nearest peers
- Your posts are automatically pinned to your local node
- Content you upvote gets cached and seeded
- Popular content distributes naturally across the network

No central server decides what loads fast and what doesn't. The network's interest in content determines its availability. Quality content, content people care about, becomes the most resilient.

---

## Part IV: The Social Surface

### Beyond Apps

With identity, agents, and content mesh as foundations, we can rethink how social interaction surfaces in the browser.

### The Unified Feed

Your social feed isn't a website you visit. It's a panel in the browser—as native as bookmarks or history:

```
┌─────────────────────────────────────────────────────────────────────┐
│ ← →  ⟳   🔒 ipfs://Qm.../article                              ☰    │
├──────────────────────────────────────────┬──────────────────────────┤
│                                          │ FEED          ▼ filter   │
│                                          │ ────────────────────────│
│      [Current page content]              │ ┌──────────────────────┐│
│                                          │ │ alice.algo      2h   ││
│                                          │ │ Just shipped the new ││
│                                          │ │ staking interface... ││
│                                          │ │         ↑ 47  💬 12  ││
│                                          │ └──────────────────────┘│
│                                          │ ┌──────────────────────┐│
│                                          │ │ bob.algo        4h   ││
│                                          │ │ Thread on impact     ││
│                                          │ │ score mechanics...   ││
│                                          │ │         ↑ 203 💬 45  ││
│                                          │ └──────────────────────┘│
│                                          │ ┌──────────────────────┐│
│                                          │ │ 🤖 agent-summary     ││
│                                          │ │ 12 posts filtered.   ││
│                                          │ │ 3 need your input.   ││
│                                          │ │       [review]       ││
│                                          │ └──────────────────────┘│
└──────────────────────────────────────────┴──────────────────────────┘
```

The feed is always there. Not demanding attention, but available. Your agent filters it down to what matters. You engage when you choose.

### Contextual Social Layer

Here's something new: *contextual social presence*.

When you're viewing any content-addressed resource, Kitsune can show you social activity *about* that content—even if the content itself isn't a social platform:

- Viewing an IPFS-hosted article? See upvotes and discussions about it from Akita's social layer
- Looking at an Arweave-archived document? See who else has engaged with it
- Browsing a decentralized marketplace listing? See the seller's social reputation

Social becomes a layer *over* content, not something you go to a separate app for. Every piece of content can have a comment thread, a reputation signal, a discussion—all anchored to content hashes, not URLs that can change.

### DM and Group Infrastructure

Private messaging, built on the same primitives:

- End-to-end encrypted by default (your root identity holds the keys)
- Group chats as mini-DAOs with their own governance
- Message storage distributed across participant nodes
- No server ever sees plaintext

This isn't novel cryptographically—Signal pioneered this years ago. What's novel is the integration: your DMs live in the same interface as your public social feed, your identity is the same, your agent can help manage both.

---

## Part V: Implementation Path

### Phase 1: Foundation (Months 1-4)

**Fork and stabilize**
- Fork Firefox ESR (Extended Support Release for stability)
- Strip telemetry and Mozilla-specific services
- Establish build pipeline and release infrastructure

**Identity core**
- Implement keypair generation and secure storage
- Build passkey integration for device binding
- Create identity backup/restore flow
- Basic wallet derivation from root identity

**IPFS integration**
- Embed js-ipfs or Helia as browser component
- Implement `ipfs://` protocol handler
- Basic pinning and storage controls
- Content loading for Akita social posts

### Phase 2: Social Integration (Months 5-8)

**Akita protocol integration**
- Smart wallet full integration
- Social contract interactions (post, upvote, reply)
- Impact score display and gating
- Graph contract queries for social connections

**Feed panel**
- Sidebar UI for social feed
- Basic filtering and sorting
- Notification system
- Compose interface for posts

**Credential system**
- Gate proof generation
- Site credential request handling
- Permission management UI

### Phase 3: Agent Runtime (Months 9-14)

**Local inference**
- WebGPU/WASM model execution
- Model management and downloading
- Inference optimization for battery/performance

**Agent sandbox**
- Isolated execution contexts
- Escrow account binding
- Permission system implementation
- Rate limiting and spending controls

**Agent UI**
- Agent creation and configuration
- Monitoring and logs
- Emergency stop controls
- Agent registry browsing

### Phase 4: Mesh Expansion (Months 15-18)

**Extended protocol support**
- Arweave gateway and native resolution
- Hypercore/Hyperdrive integration
- Cross-protocol content discovery

**Storage incentives**
- Integration with storage incentive networks
- Contribution tracking and rewards
- Configurable seeding policies

**Contextual social**
- Social overlay for arbitrary content
- Cross-content discussion threading
- Reputation aggregation across surfaces

---

## Part VI: Attack Surfaces and Mitigations

### Identity Theft

**Risk**: Root keypair compromise leads to total identity loss.

**Mitigations**:
- Hardware security module integration where available (TPM, Secure Enclave)
- Social recovery option: designate trusted identities who can collectively authorize key rotation
- Time-locked key rotation: schedule future key changes that can be cancelled if you retain access
- Identity insurance: escrow funds released to recovery identity if main goes dormant

### Agent Misbehavior

**Risk**: Agent takes actions you didn't intend, drains escrow, damages reputation.

**Mitigations**:
- Escrow isolation (already core to design)
- Mandatory simulation: agent must show you what it *would* do before first execution
- Gradual trust: agents start with minimal permissions, earn more over time
- Kill switch: browser-level emergency stop that halts all agent activity
- Audit log: every agent action recorded, reviewable, cryptographically signed

### Network Attacks

**Risk**: Eclipse attacks isolate you from the real network state. Sybil attacks flood you with fake content.

**Mitigations**:
- Multiple gateway fallbacks for Algorand state
- Content addressing makes fake content cryptographically impossible (hash won't match)
- Impact score gating filters low-reputation actors
- Peer diversity requirements in mesh connections

### Privacy Leakage

**Risk**: Correlation attacks link your activities across contexts despite lack of direct identification.

**Mitigations**:
- Separate browser contexts for separate identities (like Firefox containers, but deeper)
- Tor integration for truly sensitive browsing
- Batched transactions to obscure timing
- Stealth addresses for receiving payments

---

## Part VII: Governance and Sustainability

### How Kitsune is Governed

Kitsune is not a product. It's infrastructure. It should be governed like infrastructure—conservatively, transparently, with long time horizons.

**Option A: Akita DAO Integration**
Kitsune development is funded and directed by Akita DAO. BONES holders vote on roadmap priorities, budget allocation, release decisions. This creates alignment between protocol and client.

**Option B: Independent Foundation**
A separate Kitsune Foundation governs the browser, with its own token or membership structure. Collaborates closely with Akita but maintains independence. Better for ecosystem diversity, potentially harder to fund.

**Option C: Hybrid**
Initial development funded by Akita DAO. Once stable, spins out into independent foundation with ongoing Akita representation but broader governance. Probably the right end state.

### Funding Mechanisms

- **Akita DAO treasury**: Direct allocation for public good infrastructure
- **Grants**: Ethereum Foundation, Filecoin Foundation, Algorand Foundation all fund ecosystem infrastructure
- **Browser-level revenue share**: Optional integration with privacy-preserving search (Brave model) or other services, revenue flows to foundation
- **Support subscriptions**: Enterprises and power users pay for priority support, custom deployments

---

## Part VIII: Why This Matters

### The Owned Web

We've spent twenty years watching the web get enclosed. Services that started open became walled gardens. Protocols got replaced by platforms. Users became products.

The technology to reverse this has existed for years. What's been missing is integration—a coherent stack that makes the decentralized alternative as *usable* as the captured one.

Akita Protocol is that stack for social. Kitsune is that stack for the browser. Together, they don't just offer an alternative to the corporate web. They offer an *owned* web—infrastructure that users control, that can't be taken away, that routes value to those who create it.

### What We're Really Building

This isn't about cryptocurrency. It's not about NFTs or DeFi or any of the speculative froth that's dominated web3 discourse.

It's about three things:

**Sovereignty**: Your identity, your data, your relationships—actually yours. Not rented from a platform that can revoke access at any time.

**Alignment**: Systems where the people who create value capture value. Where attention serves users rather than extracting from them. Where governance follows contribution.

**Resilience**: Infrastructure that doesn't depend on any single company, server, or jurisdiction. Content that can't be deleted because it doesn't live in one place. Networks that get stronger as they grow.

These are old dreams. The cypherpunks had them in the 90s. What's different now is that the pieces exist. Akita built the protocol layer. Kitsune can be the interface layer. Put them together, and you have something that could actually work.

---

## Appendix A: Technical Dependencies

### Core Browser
- Firefox ESR (Extended Support Release)
- Mozilla Public License 2.0
- Gecko rendering engine

### Blockchain
- Algorand SDK (algosdk)
- Akita Protocol contracts (65 contracts)
- ARC standards for wallet connectivity

### Content Addressing
- js-ipfs / Helia (IPFS in browser)
- Arweave gateway integration
- Hypercore protocol libraries

### AI/ML
- WebGPU for hardware acceleration
- ONNX Runtime Web for model execution
- Transformers.js for model loading
- Quantized models: Llama 3.2, Phi-3.5, Mistral 7B

### Cryptography
- WebCrypto API
- libsodium.js for additional primitives
- zk-SNARK libraries for credential proofs

---

## Appendix B: Name Note

*Kitsune* (狐) is the Japanese word for fox—a nod to Firefox's heritage. In folklore, kitsune are shapeshifters and tricksters, but also faithful guardians and messengers. They grow more powerful and wise with age, sprouting additional tails.

Akita is a dog. Kitsune is a fox. Both are loyal. Both are clever. They make good companions.

---

*This document is a starting point, not a specification. The architecture will evolve as we build, as we learn, as the ecosystem develops. What matters is the direction: toward sovereignty, toward alignment, toward resilience.*

*Let's build.*
